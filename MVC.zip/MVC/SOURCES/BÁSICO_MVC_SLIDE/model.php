<?php

class Model
{
    public function getMessage()
    {
        //Aqui eu crio minhas regras,
        //por exemplo, buscar esta mensagem
        //no banco de dados
        return 'Hello World';
    }
}