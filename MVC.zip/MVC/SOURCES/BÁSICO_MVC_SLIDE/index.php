<?php

//executo o controller
include 'controller.php';
(new Controller)->action();