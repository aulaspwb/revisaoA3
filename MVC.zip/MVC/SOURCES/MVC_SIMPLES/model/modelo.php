<?php

class Modelo {
	
	public function getMensagem() {
		return "Mensagem vinda do modelo!!!!!!!!";
	}
}
?>