<?php
require_once 'controller/controlador.php';
$controlador = new Controlador(); 
$controlador->index(); 
?>