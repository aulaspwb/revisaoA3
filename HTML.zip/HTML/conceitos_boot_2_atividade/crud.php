<?php
 
require_once 'db_con.php';
 
if(isset($_POST['save']))
{
 $bname= $_POST['bname'];
 $bauthor = $_POST['bauthor'];
 
 
 $stmt = $DBcon->prepare("INSERT INTO books(name,author) VALUES(:bname, :bauthor)");
 
 $stmt->bindparam(':bname', $bname);
 $stmt->bindparam(':bauthor', $bauthor);
 $stmt->execute();
 
}
 
 
if(isset($_GET['delete_id']))
{
 $id = $_GET['delete_id'];
 $stmt = $DBcon->prepare("DELETE FROM books WHERE id=:id");
 $stmt->execute(array(':id' => $id));
 header("Location: index.php");
}
 
if(isset($_GET['edit_id']))
{
 $stmt = $DBcon->prepare("SELECT * FROM books WHERE id=:id");
 $stmt->execute(array(':id' => $_GET['edit_id']));
 $editRow=$stmt->FETCH(PDO::FETCH_ASSOC);
 
}
 
if(isset($_POST['update']))
{
 $bname = $_POST['bname'];
 $bauthor = $_POST['bauthor'];
 $id = $_GET['edit_id'];
 
 $stmt = $DBcon->prepare("UPDATE books SET name=:bname, author=:bauthor WHERE id=:id");
 $stmt->bindparam(':bname', $bname);
 $stmt->bindparam(':bauthor', $bauthor);
 $stmt->bindparam(':id', $id);
 $stmt->execute();
 header("Location: index.php");
}
 
 
?>