<?php include("ui/header.htm"); ?>
<?php include("ui/nav.htm"); ?>
<div id="content"></div>
<?php include("ui/deleteconfirmmodal.htm"); ?>
<?php include("ui/footer.htm"); ?>