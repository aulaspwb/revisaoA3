<?php
error_reporting(E_ALL ^ E_DEPRECATED);
include_once 'dbMySql.php';
$con = new DB_con();
$table = "users";
$res=$con->select($table);
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>ATIVIDADE</title>

</head>
<body>
<center>

<div id="header">
	<div id="content">
    <label>ATIVIDADE PHP - MÉTODO CONEXÃO BANCO DEPRECIADO</label>
    </div>
</div>
<div id="body">
	<div id="content">
    <table align="center">
    <tr>
    <th colspan="3"><a href="add_data.php">ADICIONAR...</a></th>
    </tr>
    <tr>
    <th>NOME</th>
    <th>SOBRENOME</th>
    <th>CIDADE</th>
    </tr>
    <?php
	while($row=mysql_fetch_row($res))
	{
			?>
            <tr>
            <td><?php echo $row[1]; ?></td>
            <td><?php echo $row[2]; ?></td>
            <td><?php echo $row[3]; ?></td>
            </tr>
            <?php
	}
	?>
    </table>
    </div>
</div>

<div id="footer">
	<div id="content">
    <hr /><br/>
    <label>Conceitos PDO - PWB: <a href="http://xvideos.com">Não clique aqui!</a></label>
    </div>
</div>

</center>
</body>
</html>