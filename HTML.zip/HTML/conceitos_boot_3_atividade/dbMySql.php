<?php
error_reporting(E_ALL ^ E_DEPRECATED);
define('DB_SERVER','localhost');
define('DB_USER','root');
define('DB_PASS' ,'123');
define('DB_NAME', 'crud_pdo_testes');

class DB_con
{
	function __construct()
	{
		$conn = mysql_connect(DB_SERVER,DB_USER,DB_PASS) or die('localhost connection problem'.mysql_error());
		mysql_select_db(DB_NAME, $conn);
	}
	
	public function insert($nome,$sobrenome,$cidade)
	{
		$res = mysql_query("INSERT users(nome,sobrenome,cidade) VALUES('$nome','$sobrenome','$cidade')");
		return $res;
	}
	
	public function select()
	{
		$res=mysql_query("SELECT * FROM users");
		return $res;
	}
}

?>