<?php
require_once 'crud.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<style type="text/css">
input
{
 width:100%;
}
</style>

<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PHP PDO CRUD Application</title>
</head>
<body>
<div class="panel">

  <form method="post">
  <table border="1" width="40%" cellpadding="15" class="table table-bordered">
  <tr>
  <td><input type="text" name="bname" placeholder="Book" required="" value="<?php if(isset($_GET['edit_id'])){ print($editRow['name']); } ?>" /></td>
  </tr>
  <tr>
  <td><input type="text" name="bauthor" placeholder="Author" required="" value="<?php if(isset($_GET['edit_id'])){ print($editRow['author']); } ?>" /></td>
  </tr>
  <tr>
  <td>
  <?php
  if(isset($_GET['edit_id']))
  {
   ?>
      <button type="submit" name="update" class="btn btn-warning">update</button>
      <?php
  }
  else
  {
   ?>
   <button type="submit" name="save" class="btn btn-success">save</button>
   <?php
  }
  ?>
  </td>
  </tr>
  </table>
  </form>

  <br />

  <?php

  $stmt = $DBcon->prepare("SELECT * FROM books ORDER BY id DESC");
  $stmt->execute();
  ?>
  <table border="1" width="40%" class="table table-bordered">
    <thead>
      <tr>
        <td>Book Name</td>
          <td>Book Author</td>
          <td>Update</td>
            <td>Delete</td>
      </tr>
    </thead>
  <?php
  if($stmt->rowCount() > 0)
  {
   while($row=$stmt->FETCH(PDO::FETCH_ASSOC))
   {
    ?>
       <tr>
       <td><?php print($row['name']); ?></td>
       <td><?php print($row['author']); ?></td>
          <td><a onclick="return confirm('Sure to Edit ? ')" href="index.php?edit_id=<?php print($row['id']); ?>">EDIT</a></td>
          <td><a onclick="return confirm('Sure to Delete ? ')" href="index.php?delete_id=<?php print($row['id']); ?>">DELETE</a></td>
       </tr>
       <?php
   }
  }
  else
  {
   ?>
      <tr>
      <td><?php print("nothing here...");  ?></td>
      </tr>
      <?php
  }
  ?>
  </table>

</div>


</body>
</html>
