CRUD com PHP PDO
----------------

Exemplo simples de utilizacao da class PDO - Cadastro, Exibicao, Edicao e Delete.