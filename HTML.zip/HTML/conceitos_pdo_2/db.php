<?php
	//arquivo de conexão
	$conn = "mysql:host=localhost;dbname=exercicio";

	try {

		$db = new PDO($conn, 'root', '123');
		$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

	} catch (PDOException $e) {
		echo $e->getMessage();
	}

?>
