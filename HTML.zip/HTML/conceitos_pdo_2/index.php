

    <h1>CRUD com PHP PDO</h1>
    <p>
      Exemplo simples de utilizacao da class PDO - Cadastro, Exibicao, Edicao e Delete.
    </p>

    <ul>
      <li><a href="cad.php">Cadastrar</a></li>
      <li><a href="exibir.php">Exibir</a></li>
      <li><a href="update.php">Atualizar</a></li>
      <li><a href="delete.php">Deletar</a></li>
    </ul>
