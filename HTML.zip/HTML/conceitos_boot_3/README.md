Curso PDO na prática arquivos da vídeo aula.

Link da vídeo aula:
http://www.youtube.com/watch?v=etcYlWwHAn0
