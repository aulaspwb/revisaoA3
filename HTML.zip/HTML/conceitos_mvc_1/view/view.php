<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>MVC PHP</title>
</head>
<body>
	<?php
		echo $mensagem;
	?>
</body>
</html>