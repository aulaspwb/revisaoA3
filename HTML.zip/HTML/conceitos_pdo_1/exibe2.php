<?php


include('conexao.php');






$sql = 'SELECT contato_nome, contato_sobrenome FROM tabela_contatos ORDER BY contato_nome';

/**
*Esquecendo aqui do prefixo, pois o drive foi definido na conexão.
*/
foreach ($conexao_pdo->query($sql) as $row) {
print $row['contato_nome'] . "\t";
print $row['contato_sobrenome'] . "\t";
echo '<br>';
}


echo '<br>';
echo '<br>';
echo '<br>';

$sth = $conexao_pdo->prepare("SELECT contato_nome, contato_sobrenome FROM tabela_contatos");
$sth->execute();
/* Fetch all of the remaining rows in the result set */
print("Buscar todas as linhas restantes:\n");
echo '<br>';
$result = $sth->fetchAll();
echo '<br>';
print_r($result);
?>