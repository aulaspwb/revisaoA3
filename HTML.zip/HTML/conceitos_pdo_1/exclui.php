<?php
include('conexao.php');


// Prepara o comando a ser executado
$prepara = $conexao_pdo->prepare("DELETE FROM tabela_contatos WHERE contato_id = ?");

// Parâmetros do comando SQL
$parametros = array( 3 );

// Executa o comando
$verifica = $prepara->execute( $parametros );

// Verifica se o comando foi executado
if ( $verifica ) {
	echo 'Linha excluída.';
} else {
	$erro = $prepara->errorInfo();
	echo 'Ocorreu um erro na sua consulta. <br>';
	echo 'Erro: ' . $erro[2];
}
?>