-- phpMyAdmin SQL Dump
-- version 4.5.4.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 17-Maio-2019 às 21:25
-- Versão do servidor: 5.7.11
-- PHP Version: 5.6.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aula_pwb`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente`
--

CREATE TABLE `cliente` (
  `idpessoa` int(11) NOT NULL,
  `nome` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `myguests`
--

CREATE TABLE `myguests` (
  `id` int(6) UNSIGNED NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `myguests`
--

INSERT INTO `myguests` (`id`, `firstname`, `lastname`, `email`, `reg_date`) VALUES
(1, 'John', 'Doe', 'john@example.com', '2019-05-17 15:40:55'),
(2, 'Mary', 'Moe', 'mary@example.com', '2019-05-17 15:40:55'),
(3, 'Julie', 'Dooley', 'julie@example.com', '2019-05-17 15:40:55'),
(4, 'John', 'Doe', 'john@example.com', '2019-05-17 15:40:55'),
(5, 'Mary', 'Moe', 'mary@example.com', '2019-05-17 15:40:55'),
(6, 'Julie', 'Dooley', 'julie@example.com', '2019-05-17 15:40:55'),
(7, 'John', 'Doe', 'john@example.com', '2019-05-17 15:40:57'),
(8, 'Mary', 'Moe', 'mary@example.com', '2019-05-17 15:40:57'),
(9, 'Julie', 'Dooley', 'julie@example.com', '2019-05-17 15:40:57');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pessoa`
--

CREATE TABLE `pessoa` (
  `idpessoa` int(11) NOT NULL,
  `nome` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `pessoa`
--

INSERT INTO `pessoa` (`idpessoa`, `nome`, `email`) VALUES
(2, 'Ana', 'ana.carolina@kindle.com'),
(3, 'Elder', 'elder@mail.com');

-- --------------------------------------------------------

--
-- Estrutura da tabela `postagens`
--

CREATE TABLE `postagens` (
  `postagem_id` int(11) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `conteudo` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `postagens`
--

INSERT INTO `postagens` (`postagem_id`, `titulo`, `conteudo`) VALUES
(1, 'Primeiro post', 'Conteudo!'),
(2, 'Segundo post', 'Conteudo!'),
(3, 'Primeiro post', 'Conteudo!'),
(4, 'Segundo post', 'Conteudo!'),
(5, 'Primeiro post', 'Conteudo!'),
(6, 'Segundo post', 'Conteudo!'),
(7, 'Primeiro post', 'Conteudo!'),
(8, 'Segundo post', 'Conteudo!'),
(9, 'Primeiro post', 'Conteudo!'),
(10, 'Segundo post', 'Conteudo!'),
(11, 'Primeiro post', 'Conteudo!'),
(12, 'Segundo post', 'Conteudo!'),
(13, 'Primeiro post', 'Conteudo!'),
(14, 'Segundo post', 'Conteudo!'),
(15, 'Primeiro post', 'Conteudo!'),
(16, 'Segundo post', 'Conteudo!'),
(17, 'Primeiro post', 'Conteudo!'),
(18, 'Segundo post', 'Conteudo!'),
(19, 'Primeiro post', 'Conteudo!'),
(20, 'Segundo post', 'Conteudo!'),
(21, 'Primeiro post', 'Conteudo!'),
(22, 'Segundo post', 'Conteudo!'),
(23, 'Primeiro post', 'Conteudo!'),
(24, 'Segundo post', 'Conteudo!'),
(25, 'Primeiro post', 'Conteudo!'),
(26, 'Segundo post', 'Conteudo!'),
(27, 'Primeiro post', 'Conteudo!'),
(28, 'Segundo post', 'Conteudo!'),
(29, 'Primeiro post', 'Conteudo!'),
(30, 'Segundo post', 'Conteudo!'),
(31, 'Primeiro post', 'Conteudo!'),
(32, 'Segundo post', 'Conteudo!'),
(33, 'Primeiro post', 'Conteudo!'),
(34, 'Segundo post', 'Conteudo!'),
(35, 'Primeiro post', 'Conteudo!'),
(36, 'Segundo post', 'Conteudo!'),
(37, 'Primeiro post', 'Conteudo!'),
(38, 'Segundo post', 'Conteudo!'),
(39, 'Primeiro post', 'Conteudo!'),
(40, 'Segundo post', 'Conteudo!'),
(41, 'Primeiro post', 'Conteudo!'),
(42, 'Segundo post', 'Conteudo!'),
(43, 'Primeiro post', 'Conteudo!'),
(44, 'Segundo post', 'Conteudo!');

-- --------------------------------------------------------

--
-- Estrutura da tabela `programadores`
--

CREATE TABLE `programadores` (
  `id` int(10) UNSIGNED NOT NULL,
  `nome` varchar(80) NOT NULL,
  `site` varchar(120) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `programadores`
--

INSERT INTO `programadores` (`id`, `nome`, `site`) VALUES
(1, 'Beraldo', 'http://rberaldo.com.br'),
(2, 'João', NULL),
(3, 'Maria', 'http://mariaprogramadora.com.br'),
(4, 'José', 'http://joseprogramador.com.br'),
(5, 'Linus Torvalds', 'http://kernel.org'),
(6, 'Mark Zuckerberg', 'http://facebook.com'),
(7, 'Steve Wozniak', 'http://apple.com'),
(16, 'Bill Gates1', 'http://microsoft.com'),
(17, 'Bill Gates1', 'http://microsoft.com');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tabela_contatos`
--

CREATE TABLE `tabela_contatos` (
  `contato_id` int(11) NOT NULL,
  `contato_nome` varchar(40) DEFAULT NULL,
  `contato_sobrenome` varchar(40) DEFAULT NULL,
  `contato_email` varchar(50) DEFAULT NULL,
  `contato_site` varchar(255) DEFAULT NULL,
  `contato_data_nascimento` datetime DEFAULT '0000-00-00 00:00:00',
  `contato_telefone` varchar(25) DEFAULT NULL,
  `contato_descricao` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tabela_contatos`
--

INSERT INTO `tabela_contatos` (`contato_id`, `contato_nome`, `contato_sobrenome`, `contato_email`, `contato_site`, `contato_data_nascimento`, `contato_telefone`, `contato_descricao`) VALUES
(1, 'Pedro', 'Alves', 'pedro@gmail.com', 'www.pedro.com.br', '2019-05-17 00:00:00', '(65)99989-5654', 'Aula PWB!!!!'),
(2, 'Manuel', 'Lopes', 'manuel@gmail.com', 'www.manuel.com', '2019-05-17 00:00:00', '(65)3256-7852', 'Aula pwb!!');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`idpessoa`);

--
-- Indexes for table `myguests`
--
ALTER TABLE `myguests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pessoa`
--
ALTER TABLE `pessoa`
  ADD PRIMARY KEY (`idpessoa`);

--
-- Indexes for table `postagens`
--
ALTER TABLE `postagens`
  ADD PRIMARY KEY (`postagem_id`);

--
-- Indexes for table `programadores`
--
ALTER TABLE `programadores`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tabela_contatos`
--
ALTER TABLE `tabela_contatos`
  ADD PRIMARY KEY (`contato_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cliente`
--
ALTER TABLE `cliente`
  MODIFY `idpessoa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `myguests`
--
ALTER TABLE `myguests`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `pessoa`
--
ALTER TABLE `pessoa`
  MODIFY `idpessoa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `postagens`
--
ALTER TABLE `postagens`
  MODIFY `postagem_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT for table `programadores`
--
ALTER TABLE `programadores`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `tabela_contatos`
--
ALTER TABLE `tabela_contatos`
  MODIFY `contato_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
