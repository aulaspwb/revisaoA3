<?php


include('conexao.php');


// Prepara o comando a ser executado
$prepara = $conexao_pdo->prepare('SELECT * FROM tabela_contatos WHERE contato_id = ? OR contato_id = ?');

// Parâmetros do comando SQL
$parametros = array( 2, 1 );

// Executa o comando
$prepara->execute( $parametros );

// Laço para exibir todas as linhas
while ( $linha = $prepara->fetch() ) {
	echo 'Nome: ' . $linha['contato_nome'] . '<br>';
	echo 'Sobrenome: ' . $linha['contato_sobrenome'] . '<br>';
	// ... E assim por diante ... 
}


?>