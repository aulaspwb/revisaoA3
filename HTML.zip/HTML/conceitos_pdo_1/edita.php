<?php



include('conexao.php');


// Prepara o comando a ser executado
$prepara = $conexao_pdo->prepare(
	"UPDATE tabela_contatos SET contato_nome = ? WHERE contato_id = ? "
);

// Parâmetros do comando SQL
$parametros = array('Serafim', 3);

// Executa o comando
$verifica = $prepara->execute( $parametros );

// Verifica se o comando foi executado
if ( $verifica ) {
	echo 'Dados enviados à base de dados com sucesso';
} else {
	$erro = $prepara->errorInfo();
	echo 'Ocorreu um erro na sua consulta. <br>';
	echo 'Erro: ' . $erro[2];
}

?>