<?php


include('conexao.php');


// Prepara o comando a ser executado
$prepara = $conexao_pdo->prepare(
	"INSERT INTO `aula_pwb`.`tabela_contatos` (
	  `contato_nome`,
	  `contato_sobrenome`,
	  `contato_email`,
	  `contato_site`,
	  `contato_data_nascimento`,
	  `contato_telefone`,
	  `contato_descricao`
	) 
	VALUES ( 
		?, 
		?,
		?, 
		?, 
		?, 
		?, 
		?
	)"
);

// Parâmetros do comando SQL
$parametros = array( 
	'Josildo',
	'Silva de Oliveira',
	'contato@todoespacoonline.com/w',
	'http://www.todoespacoonline.com/w',
	'1987-04-20 13:45:57',
	'+553588888888',
	'Meu nome é José Silva de Oliveira e tenho 27 anos.'
);

// Executa o comando
$verifica = $prepara->execute( $parametros );

// Verifica se o comando foi executado
if ( $verifica ) {
	echo 'Dados enviados à base de dados com sucesso';
} else {
	$erro = $prepara->errorInfo();
	echo 'Ocorreu um erro na sua consulta. <br>';
	echo 'Erro: ' . $erro[2];
}


?>