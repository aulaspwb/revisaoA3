<?php


include('conexao.php');



// A classe PDO prepara o comando a ser executado
$prepara = $conexao_pdo->prepare('SELECT * FROM tabela_contatos');

// A classe PDO executa o comando
$prepara->execute();


// Laço para exibir todas as linhas
while ( $linha = $prepara->fetch() ) {
echo 'Nome: ' . $linha['contato_nome'] . '<br>';

echo 'Sobrenome: ' . $linha['contato_sobrenome'] . '<br>';
// ... E assim por diante ...
echo '<br>';

}



?>