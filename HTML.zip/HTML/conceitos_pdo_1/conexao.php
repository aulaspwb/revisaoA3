<?php


/* Variáveis para conexão PDO */
$base_dados = 'aula_pwb';
$usuario_bd = 'root';
$senha_bd = '123';
$host_db = 'localhost';



$conexao_pdo = null;


// Instância PDO
//$conexao_pdo = new PDO('mysql:host=IP_OU_HOST_AQUI;dbname=NOME_DO_BD', 'USUÁRIO', 'SENHA');



/* Concatenação das variáveis para detalhes da classe PDO */
$detalhes_pdo = 'mysql:host=' . $host_db . ';dbname='. $base_dados;



// Tenta conectar
try {
// Cria a conexão PDO com a base de dados
$conexao_pdo = new PDO($detalhes_pdo, $usuario_bd, $senha_bd);

//echo "string";
} catch (PDOException $e) {
// Se der algo errado, mostra o erro PDO
print "Erro: " . $e->getMessage() . "<br/>";


}
?>