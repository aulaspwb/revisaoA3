<?php

define('HOST', 'localhost');
define('USER', 'root');
define('PASS', '123');
define('BASE', 'aula_24_05');

