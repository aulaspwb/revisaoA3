<?php
require_once('Database.php');
require_once('configuracao.php');



$id = 17;
$conn = new Database();

$stm = $conn->getConexao()->prepare('SELECT * FROM `pessoa` WHERE `idpessoa` = :ID');
$stm->bindValue(':ID', $id, PDO::PARAM_INT);



if( $stm->execute() ) {
    $resultado = $stm->fetch(PDO::FETCH_ASSOC);
    print_r($resultado);
}