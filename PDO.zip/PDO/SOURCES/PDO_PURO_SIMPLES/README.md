Exemplo conexão PDO
==========
Para os que tem dúvidas sobre a conexão e o uso do PDO.