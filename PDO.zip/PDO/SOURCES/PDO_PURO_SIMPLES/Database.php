<?php

class Database
{

    private $conn;
    public function __construct()
    {
        try {
            // Conexão MySQL
             $this->conn = new PDO('mysql:host=localhost;dbname=exercicio', 'root', '123');
        }
        catch(PDOException $e) {
            throw $e;
        }
    }

    /**
     * Recupera a conexão PDO
     * @return PDO
     */
    public function getConexao()
    {
        return $this->conn;
    }
}