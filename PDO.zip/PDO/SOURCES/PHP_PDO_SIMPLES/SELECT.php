<?php

$conn = new PDO("mysql:dbname=exercicio;host=localhost", "root", "123");


$stmt = $conn->prepare("SELECT * FROM pessoa ORDER BY idpessoa");

$stmt->execute();

$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($results as $row) {

	foreach ($row as $key => $value) {
		
		echo "<strong>".$key.":</strong>".$value."<br/>";
	}

	echo "====================================<br>";
	
}