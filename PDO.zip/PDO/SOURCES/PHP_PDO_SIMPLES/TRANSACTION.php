<?php

$conn = new PDO("mysql:dbname=exercicio;host=localhost", "root", "123");

$conn->beginTransaction();

$stmt = $conn->prepare("DELETE FROM pessoa WHERE idpessoa = ?");

$id = 19;

$stmt->execute(array($id));

$conn->rollback();

echo "Delete OK!";