<?php

$conn = new PDO("mysql:dbname=exercicio;host=localhost", "root", "123");


$stmt = $conn->prepare("UPDATE pessoa SET nome = :NOME, email = :EMAIL WHERE idpessoa = :ID");






$nome = "Renato Freis Caneca";
$email = "gabriel@fapan.edu.br";
$id = 19;


$stmt->bindParam(":NOME", $nome);
$stmt->bindParam(":EMAIL", $email);
$stmt->bindParam(":ID", $id);

$stmt->execute();

echo "Alterado ok";

