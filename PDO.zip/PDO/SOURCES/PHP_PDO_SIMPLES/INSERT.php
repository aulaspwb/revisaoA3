<?php

$conn = new PDO("mysql:dbname=exercicio;host=localhost", "root", "123");

$stmt = $conn->prepare("INSERT INTO pessoa (idpessoa, nome, email) VALUES (:ID, :NOME,:EMAIL)");

$id = "4";
$nome = "Belani Nogueira";
$email = "belani@fapan.edu.br";

$stmt->bindParam(":ID", $id);
$stmt->bindParam(":NOME", $nome);
$stmt->bindParam(":EMAIL", $email);

$stmt->execute();

echo "Inserido ok";






