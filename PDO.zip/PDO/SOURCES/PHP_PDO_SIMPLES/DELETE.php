<?php

$conn = new PDO("mysql:dbname=exercicio;host=localhost", "root", "123");

$stmt = $conn->prepare("DELETE FROM pessoa WHERE idpessoa = :ID");

$id = 4;

$stmt->bindParam(":ID", $id);

$stmt->execute();

echo "Delete ok";